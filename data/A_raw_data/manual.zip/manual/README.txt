--------------------------------------------------------------------------------
Summary
--------------------------------------------------------------------------------
This directory contains manually collected data. The following files are
available:

    harvest_weights.csv
        A comma-separated values (CSV) file containing the fresh weight of
        crop at harvest and the weight of any flower heads.

    physical.csv
        A CSV file containing crop height, diameter, fresh weight, dry weight,
        flower head weight, dry flower head weight, and relative water content.

    SPAD.csv
        A CSV file containing SPAD measurements throughout the season.


--------------------------------------------------------------------------------
Citation
--------------------------------------------------------------------------------
If this data is used in a publication, please cite both the article
(http://doi.org/10.1002/rob.21877) and the dataset
(http://doi.org/10.25910/5c941d0c8bccb). For more details and attribution
information please refer to README.txt in the root location of this dataset.

--------------------------------------------------------------------------------
License
--------------------------------------------------------------------------------
Ladybird Cobbitty 2017 Brassica Dataset (c) by
Asher Bender, Brett Whelan, Salah Sukkarieh

Ladybird Cobbitty 2017 Brassica Dataset is licensed under a
Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License.

Please refer to LICENSE.txt in the root location of this dataset for a copy of
the CC BY-NC-SA 4.0 license. If you cannot access the included CC BY-NC-SA 4.0
license, see <http://creativecommons.org/licenses/by-nc-sa/4.0/>.
